<?php
include('../config/constants.php');
include('./login-check.php');
?>

<html>

<head>
    <title>Tasty Meal</title>
    <link rel="stylesheet" type="" href="../css/stylehome.css">
</head>

<body>
    <section class="header"> <!-- css on line 8 -->
        <nav> <!-- css on line 18-->
            <a href="#"><img src="../images/yum.png"></a> <!-- css on line 22 --> <!-- logo -->
            <div class="nav-links"> <!-- css on line 31 --> <!-- title -->
                <ul><b> <!-- css on line  37 -->
                        <li>
                            <a href="#section">Home</a> <!-- css on line 50 -->
                        <li>
                        <li>
                            <a href="#section2">About us</a>
                        <li>
                        <li>
                            <a href="#section3">contact</a>
                        <li>
                        <li>
                            <a href="./menu.php">Menu</a>
                        </li>
                        <li>
                        <a href="<?php echo SITEURL; ?>pages/user_profile.php">
                            Hello <?php echo $_SESSION['user']; ?>!</a>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="text-box"> <!-- css on line 72 --> <!-- middle -->
            <h1><b>Home made tiffin service</b></h1> <!-- css on line 83 -->
            <p><b>स्वस्थ खानुहोस् स्वस्थ रहनुहोस्</b></p> <!-- css on line 88 -->
        </div>
    </section>
    <div id="section2"><!-- css on line 101 --> <!-- About us -->
        <h1>About us</h1>
        <br /> 
        <h2><u>Tasty Meal</u></h2>
        <h3><u>Thank You for visiting us..</u> </h3>
        <br /> 
        <p>We provide home made healthy meal for our visitors. You can get breakfast, lunch, dinner, sweets too at their preffered address, so our users can be satisfy.<br>
            Customers can have choice of deciding their own personalize menu.<br><br />
        <p> It will be well packed with aluminium foil without any use of polythene<br>Delivery Services in all over Biratnagar </p><br> 
        <p>Pure and fresh vegetarian meal</p><br> 
        </p>
        <h2><u>Service Time/ Order Timing</u></h2> <br />
        <p><b>Breakfast:</b> A day before 7Pm<br> <br />
            <b>Lunch:</b> A day before till 6PM<br> <br />
            <b>Dinner:</b> Same day before 12PM</p> <br />
        <h2><u>Delivery Timing</u></h2> <br />
        <p><b>Breakfast:</b> Morning 9AM-12PM<br> <br />
            <b>Lunch:</b> Afternoon 12PM-5PM<br> <br />
            <b>Dinner:</b> Evening: 7PM-9PM</p>
    </div>
    <div id="section3"> <!-- css on line 109 --> <!-- Contact -->
        <center>
            <h1>contact us</h1> <br /> 
            <div class="contact">
                <h3>Phone No: 9807335640</h3>
            </div> <br /> 
            <div class="contact">
                <h3>Faxx No: +977 981 1072 440</h3>
            </div> <br /> 
            <div class="contact">
                <h3>Email: Sharmaneha2073@gmail.com</h3>
            </div>  <br />
            <div class="contact">
                <h3>Location: Biratnagar-6,Morang</h3>
            </div>
        </center> <br /> <br />
        <center>
            <div class="contact">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114311.
                    32531362747!2d87.2017662591932!3d26.44834907963289!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.
                    1!3m3!1m2!1s0x39ef744704331cc5%3A0x6d9a85e45c54b3fc!2z4KSs4KS_4KSw4KS-4KSf4KSo4KSX4KSwIDU2NjEz!5e0!3m2!1sne!2snp!4v1653193797982!5m2!1sne!2snp" height="100%" width="100%" tyle="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </center>
    </div>
</body>

</html>