<?php
include('../config/constants.php');
include('./login-check.php');
?>


<?php
//check whether food is is set or not
if (isset($_GET['id'])) {
    $uid = $_SESSION['uid'];
    //get the food id and details of the selected food
    $id = $_GET['id'];
    //get the details of selected food
    $sql = "SELECT * FROM items WHERE id =$id";
    //execute the query
    $res = mysqli_query($conn, $sql);
    //count the rows
    $count = mysqli_num_rows($res);
    //check whether the data is available or not
    if ($count == 1) {
        //we have data
        //get the data from the data base
        $row = mysqli_fetch_assoc($res);
        $title = $row['title'];
        $category = $row['category_id'];
        $price = $row['price'];
    } else {
        //food not available and ridirect
        header('location:' . SITEURL);
    }
} else {
    //redirect to home page
    header('location:' . SITEURL);
}
?>
<html>
    <head>
       <link rel="stylesheet" href="../css/form.css">
    </head>
    <body>
<!-- fOOD sEARCH Section Starts Here -->
<section class="food-search">
    <div class="container">
        <div class="center">
            <h1>Order Confirmation</h1>
            <form action="" method="POST" action="">
              
                    <div>
                        <h3>Item: <?php echo $title; ?></h3>
                        <input type="hidden" name="item" value="<?php echo $title; ?>">
                        <h3>Category:<?php echo $category; ?></h3>
                        <input type="hidden" name="category" value="<?php echo $category; ?>">
                        <p class="food-price">Price: Rs<?php echo $price; ?></p>
                        <input type="hidden" name="price" value="<?php echo $price; ?>">
                        <div class="order-label">Quantity</div>
                       <input type="number" name="qty" class="input-responsive" value="1" required>
                    </div>
            
                   
                        <div class="txt_field">
                            <input type="text" name="full-name" class="input-responsive" required><span></span><label>Full Name</label>
                        </div>
                        <div class="txt_field">
                            <input type="text" name="contact" class="input-responsive" required><span></span><label>Phone Number</label>
                        </div>
                        <div class="txt_field">
                            <input type="textarea" name="address" rows="10" class="input-responsive" required><span></span><label>Address</label>
                        </div>
                        <div class="txt_field">
                            <input type="submit"  name="submit" value="Confirm Order" class="btn btn-primary">
                        </div>
            </form>
        </div>
        <?php
        //check whether submit button is clicked or not
        if (isset($_POST['submit'])) {
            //get all the details from the form 
            $item = $_POST['item'];
            $category = $_POST['category'];
            $price = $_POST['price'];
            $qty = $_POST['qty'];
            $total = $price * $qty; //total= price * qty
            $order_date = date("Y-m-d h:i:sa"); //order date
            $status = "Ordered"; //ordered, on delivery, delivered , cancelled
            $customer_name = $_POST['full-name'];
            $customer_contact = $_POST['contact'];
            /* $customer_email = $_POST['email']; */
            $customer_address = $_POST['address'];
            //save the order in database
            //create sql to save the data
            $sql2 = "INSERT INTO orders SET
            item = '$item',
            category_id = '$category',
            price = $price,
            qty = $qty,
            total = $total,
            order_date = '$order_date',
            status = '$status',
            customer_name = '$customer_name',
            customer_contact = '$customer_contact',
            customer_address = '$customer_address',
            uid = '$uid'
            "; 
            //execute the query
            $res2 = mysqli_query($conn, $sql2);
            //check whether query executed successfully or not
            if ($res2 == true) {
                //query executed and order saved
                $_SESSION['order'] = "<div class='success text-center'> Food Ordered Succcessfully. 
                <br> Order Will Arrive After 1 Hour.
                <br> Pay Through Cash During Delivery Time(CASH ON DELIVERY).
                <br>(THIS SITE IS FOR TRIAL PERIOD SO SORRY FOR YOUR INCOMPPLETE ORDER).
                <br> Have A Nice Day.
                </div>";
                header('location:' . SITEURL . 'pages/home.php');
            } else {
                //fail to save order
                $_SESSION['order'] = "<div class='error text-center'> Failed TO Order Food</div>";
                header('location:' . SITEURL);
            }
        }
        ?>
    </div>
</section>
</body>

</html>










