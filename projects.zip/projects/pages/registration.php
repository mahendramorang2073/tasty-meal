<?php
include('../config/constants.php');
?>

<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>User Registration</title>
    <link rel="stylesheet" href="../css/form.css">
</head>

<body>
    <?php

    // When form submitted, insert values into the database.
    if (isset($_REQUEST['username'])) {
        // removes backslashes
        $username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
        $username = mysqli_real_escape_string($conn, $username);
        $email    = stripslashes($_REQUEST['email']);
        $email    = mysqli_real_escape_string($conn, $email);
        $contact  = stripslashes($_REQUEST['contact']);
        $contact   = mysqli_real_escape_string($conn, $contact);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($conn, $password);
        $query    = "INSERT INTO `users`(`user_id`, `username`, `email`, `contact`, `password`) VALUES ('','$username','$email','$contact', '" . md5($password) . "')";
        $result   = mysqli_query($conn, $query);
        if ($result) {
            //create a session variable to display  message
            $_SESSION['add'] = "<div class='success'>User Added Successfully</div>";
            //redirect page to manage admin
            header("location:" . SITEURL . 'index.php');
        } else {
            //Failed to inserted
            //echo"Failed to insert data";
            //create a session variable to display  message
            $_SESSION['add'] = "<div class='error'>Failed To Add User</div>";
            //redirect page to add admin
            header("location:" . SITEURL . 'registration.php');
        }
    } else {
    ?>
        <div class="center">
            <h1>Registration</h1>
            <form method="post" action="">
                <div class="txt_field">
                    <input type="text" name="username" pattern="[a-z]{1,15}" title="Username should only contain lowercase letters. e.g. john" maxlength="10" required />
                    <span></span>
                    <label>Username</label>
                </div>
                <div class="txt_field">
                    <input type="text" name="email" id="email" pattern="^[a-z0-9](\.?[a-z0-9]){5,}@g(oogle)?mail\.com$" title="Enter your valid gmail id" required />
                    <span></span>
                    <label>Email</label>
                </div>
                <div class="txt_field">
                    <input type="tel" name="contact" id="phone" pattern="^[9]\d{9,9}$" title="Phone number starts with 9 and remaing 9 digit with 0-9" maxlength="10" required />
                    <span></span>
                    <label>Phone Number</label>
                </div>
                <div class="txt_field">
                    <input type="password" name="password" id="pwd" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required />
                    <span></span>
                    <label>Password</label>
                </div>
                <input type="submit" name="submit" value="Login">
                <div class="signup_link">
                    already have an account? <a href="../index.php">Sign-In</a>
                </div>
            </form>
        </div>
        </form>
        </div>
    <?php
    }
    ?>

</body>

</html>