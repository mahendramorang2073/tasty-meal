<?php
include('../config/constants.php');
include('./login-check.php');
?>

<html>
<head>
    <title>
        Menu
    </title>
    <link rel="stylesheet" href="../css/menu.css">
</head>
<body>
    <header>
        <div class="overlay"></div>
        <nav>
            <div align="center" class="col-md-12 text-center" id="menu-filters">
                <ul>
                    <li><a href="#section2" class="filter" data-filter=".menu-restaurant">Breakfast menu</a></li>
                    <li><a href="#section3" class="filter" data-filter=".menu-restaurant">Lunch menu</a></li>
                    <li><a href="#section4" class="filter" data-filter=".menu-restaurant">Dinner menu</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <br>
    <div class="container" img src="../images/food3.jpeg">
        <div id="section2">
            <h1>Breakfast Menu</h1>
            <table align="center" cellspacing=40 cellpadding=20 width=80% height=30%>
                <tr class="text"><b>
                        <center>
                            <th>Days</th>
                            <th>Items</th>
                            <th>Description</th>
                            <th>Price/plate(RS)</th>
                            <th>Action</th>
                    </b></center>
                </tr>
                <?php
                $sql = "SELECT * FROM items WHERE category_id='1' and featured='yes';";
                $data = mysqli_query($conn, $sql);

                while ($row = mysqli_fetch_assoc($data)) {
                    echo '
                                <tr> 
                                <td>' . $row['day'] . '</td>
                                <td>' . $row['title'] . '</td>
                                <td>' . $row['description'] . '</td>
                                <td>' . $row['price'] . '</td>
                                <td><a href="./order.php?id=' . $row['id'] . '" style="color: navy;"">Order Now</a></td>
                                </b>
                                </tr>
                                
                                ';
                }
                ?>
            </table><br>
        </div>
        <br>
        <br>
        <div id="section3">
            <h1>Lunch Menu</h1>
            <table align="center" cellspacing=40 cellpadding=20 width=80% height=30%>
                <tr class="text"><b>
                        <center>
                            <th>Days</th>
                            <th>Items</th>
                            <th>Description</th>
                            <th>Price/plate(RS)</th>
                            <th>Action</th>
                    </b></center>
                </tr>
                <?php
                $sql1 = "SELECT * FROM items WHERE category_id='2' and featured='yes';";
                $data1 = mysqli_query($conn, $sql1);

                while ($row1 = mysqli_fetch_assoc($data1)) {
                    echo '
                                <tr> 
                                <td>' . $row1['day'] . '</td>
                                <td>' . $row1['title'] . '</td>
                                <td>' . $row1['description'] . '</td>
                                <td>' . $row1['price'] . '</td>
                                <td><a href="./order.php?id=' . $row1['id'] . '" style="color: navy;"">Order Now</a></td>
                                </b>
                                </tr>
                                
                                ';
                }
                ?>
            </table><br>
        </div>

        <div id="section4">
            <h1>Dinner Menu</h1>
            <table align="center" cellspacing=40 cellpadding=20 width=80% height=30%>
                <tr class="text"><b>
                        <center>
                            <th>Days</th>
                            <th>Items</th>
                            <th>Description</th>
                            <th>Price/plate(RS)</th>
                            <th>Action</th>
                    </b></center>
                </tr>
                <?php
                $sql2 = "SELECT * FROM items WHERE category_id='1' and featured='yes';";
                $data2 = mysqli_query($conn, $sql2);
                while ($row2 = mysqli_fetch_assoc($data2)) {
                    echo '
                                <tr> 
                                <td>' . $row2['day'] . '</td>
                                <td>' . $row2['title'] . '</td>
                                <td>' . $row2['description'] . '</td>
                                <td>' . $row2['price'] . '</td>
                                <td><a href="./order.php?id=' . $row2['id'] . '" style="color: navy;"">Order Now</a></td>
                                </b>
                                </tr>
                                
                                ';
                }
                ?>
            </table><br>
        </div>
        <br>
    </div>
    <script src="../javascript/main.js"></script>
</body>
</html>