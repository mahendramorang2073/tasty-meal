<?php
include('../config/constants.php');
?>

<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Admin Registration</title>
    <link rel="stylesheet" href="../css/form.css">
</head>

<body>
    <?php

    // When form submitted, insert values into the database.
    if (isset($_REQUEST['username'])) {
        // removes backslashes
        $username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
        $username = mysqli_real_escape_string($conn, $username);
        $password = stripslashes($_REQUEST['password']);
        $password = mysqli_real_escape_string($conn, $password);
        $query    = "INSERT INTO `admin`(`id`, `username`, `password`) VALUES ('','$username','" . md5($password) . "')";
        $result   = mysqli_query($conn, $query);
        if ($result) {
            //create a session variable to display  message
            $_SESSION['add'] = "<div class='success'>User Added Successfully</div>";
            //redirect page to manage admin
            header("location:" . SITEURL . 'admin/login.php');
        } else {
            //Failed to inserted
            //echo"Failed to insert data";
            //create a session variable to display  message
            $_SESSION['add'] = "<div class='error'>Failed tO Add User</div>";
            //redirect page to add admin
            header("location:" . SITEURL . 'admin/register.php');
        }
    } else {
    ?>
        <div class="center">
            <h1>Registration</h1>
            <form method="post" action="">
                <div class="txt_field">
                    <input type="text" name="username" required>
                    <span></span>
                    <label>Username</label>
                </div>
                <div class="txt_field">
                    <input type="password" name="password" required>
                    <span></span>
                    <label>Password</label>
                </div>
                <input type="submit" name="submit" value="Login">
                <div class="signup_link">
                    already have an account? <a href="./login.php">Sign-In</a>
                </div>
            </form>
        </div>
    <?php
    }
    ?>

</body>

</html>