<?php
include('partials/menu.php');
?>
<div class="main-contain">
    <div class="wrapper">
        <h1>Add Food</h1>

        <br /> <br />
        <?php
        if (isset($_SESSION['upload'])) {
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
        }

        if (isset($_SESSION['add'])) //checking whterher the session is set or not
        {
            echo $_SESSION['add']; //Display the session message
            unset($_SESSION['add']); //remove session message
        }
        ?>

        <form action="" method="POST">

            <table class="tbl-30">
                <tr>
                    <td>Title:</td>
                    <td> <input type="text" name="title" placeholder="Title Of Food"> </td>
                </tr>
                <tr>
                    <td>Day:</td>
                    <td> <input type="text" name="day" placeholder="Day"> </td>
                </tr>
                <tr>
                    <td>Description:</td>
                    <td> <textarea name="description" cols="20" rows="5" placeholder="Enter the description here"></textarea></td>
                </tr>
                <td>Price:</td>
                <td> <input type="number" name="price" placeholder="Enter the price"></td>
                </tr>
                <tr>
                    <td>Category:</td>
                    <td>
                        <select name="category">
                            <?php
                            //create php code to display categories from database
                            //1.create sql to get all active categories from database
                            $sql = "SELECT * FROM category WHERE active='yes'";
                            //executing query
                            $res = mysqli_query($conn, $sql);
                            //count rows to check whether wee have categories or not
                            $count = mysqli_num_rows($res);
                            //if count is greater than 0, we have categories else we don'n have categories
                            if ($count > 0) {
                                //we have categories
                                while ($row = mysqli_fetch_assoc($res)) {
                                    //get the details of category 
                                    $id = $row['id'];
                                    $title = $row['title'];
                            ?>
                                    <option value="<?php echo $id; ?>"> <?php echo $title; ?> </option>
                                <?php
                                }
                            } else {
                                //we dont have category
                                ?>
                                <option value="0"> No Category Found </option>
                            <?php
                            }
                            //2.display on dropdoun
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Featured:</td>
                    <td>
                        <input type="radio" name="featured" value="Yes"> Yes
                        <input type="radio" name="featured" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td>Active:</td>
                    <td>
                        <input type="radio" name="active" value="Yes"> Yes
                        <input type="radio" name="active" value="No"> No
                    </td>
                </tr>
                <tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add Item" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>

        <?php
        //check whether the button is clicked or not
        if (isset($_POST['submit'])) {
            //add food to database
            // echo "button clicked";

            //1. get the data from form
            $title = mysqli_real_escape_string($conn, $_POST['title']);
            $day = mysqli_real_escape_string($conn, $_POST['day']);
            $description = mysqli_real_escape_string($conn, $_POST['description']);
            $price = mysqli_real_escape_string($conn, $_POST['price']);
            $category = mysqli_real_escape_string($conn, $_POST['category']);
            $day = mysqli_real_escape_string($conn, $_POST['day']);

            //check whether radio button for featured and active is checked or not
            if (isset($_POST['featured'])) {
                $featured = $_POST['featured'];
            } else {
                $featured = "No";
            }

            if (isset($_POST['active'])) {
                $active = $_POST['active'];
            } else {
                $active = "No";
            }


            //3. insert into database
            //create a sql query to save or add food
            //for numerical we do not need to pass value inside quotes'' but for string it is compulsary to add quotes''
            $sql2 = "INSERT INTO items SET
                    title = '$title',
                    day = '$day',
                    description = '$description',
                    price = $price,
                    category_id = $category,
                    featured = '$featured',
                    active = '$active'
            ";
            //execute the query
            $res1 = mysqli_query($conn, $sql2);
            //check whether data inserted or not
            //4. redirect with message to manage food page
            if ($res1 == true) {
                //data inserted successfully
                $_SESSION['add'] = "<div class ='success'> Food Added Successfully</div>";
                header('location:' . SITEURL . 'admin/manage-items.php');
            } else {
                //failed to insert data
                $_SESSION['add'] = "<div class ='error'> Failed To Add food</div>";
                header('location:' . SITEURL . 'admin/manage-items.php');
            }
        }
        ?>
    </div>
</div>

