<?php
include('partials/menu.php');
?>
<div class="main-contain">
    <div class="wrapper">
        <h1> Update Categoty</h1>

        <br /> <br />

        <?php

        //check whether the is is set or not
        if (isset($_GET['id'])) {
            //Get the id and all other details
            //echo "Getting the data";
            $id = $_GET['id'];
            //create sql query to get all other detail
            $sql = "SELECT * FROM category WHERE id=$id";

            //execute the query
            $res = mysqli_query($conn, $sql);

            //count the rows to check whether the id is valid or not
            $count = mysqli_num_rows($res);

            if ($count == 1) {
                //get all the data
                $row = mysqli_fetch_assoc($res);
                $title = $row['title'];
                $featured = $row['featured'];
                $active = $row['active'];
            } else {
                //redirect to manage category with session message
                $_SESSION['no-category-found'] = "<div class='error'> Category Not Found</div>";
                //redirecting
                header('location:' . SITEURL . 'admin/manage-category.php');
            }
        } /* else {
            //redirect to manage category
            header('location:' . SITEURL . '/admin/manage-category.php');
        } */

        ?>

        <form action="" method="POST">

            <table class="tbl-30">
                <tr>
                    <td>Title:</td>
                    <td> <input type="text" name="title" value="<?php echo $title; ?>"></td>
                </tr>
<!--                 <tr>
                    <td>Day:</td>
                    <td> <input type="text" name="day" value="<?php echo $day; ?>"></td>
                </tr> -->

                <tr>
                    <td>Featured:</td>
                    <td> <input <?php if ($featured == "Yes") { 
                                    echo "checked";
                                } ?> type="radio" name="featured" value="Yes"> Yes
                        <input <?php if ($featured == "No") {
                                    echo "checked";
                                } ?> type="radio" name="featured" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td>Active:</td>
                    <td> <input <?php if ($active == "Yes") {
                                    echo "checked";
                                } ?> type="radio" name="active" value="Yes"> Yes
                        <input <?php if ($active == "No") {
                                    echo "checked";
                                } ?> type="radio" name="active" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="Update Category" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>

        <?php
        if (isset($_POST['submit'])) {
            //echo "clicked";
            //1.get all the values from our form
            $id = mysqli_real_escape_string($conn, $_POST['id']);
            $title = mysqli_real_escape_string($conn, $_POST['title']);
            /* $day = mysqli_real_escape_string($conn, $_POST['day']); */
            $featured = mysqli_real_escape_string($conn, $_POST['featured']);
            $active = mysqli_real_escape_string($conn, $_POST['active']);

            //3.update the database
            $sql1 = "UPDATE category SET
                title = '$title',
              /*   day ='$day', */
                featured = '$featured',
                active = '$active'
                WHERE id =$id
                ";
            //execute the query
            $res1 = mysqli_query($conn, $sql1);
            //4.redirect to manage category with message
            //check whether executed or not
            if ($res1 == TRUE) {
                //category update
                $_SESSION['update'] = "<div class='success'>Category Updated Successfully </div>";
                //redirecting
                header('location:' . SITEURL . 'admin/manage-category.php');
            } else {
                //failed to update category
                $_SESSION['update'] = ">div class='error'>Failed To Update Category</div>";
                //redirecting
                header('location:' . SITEURL . 'admin/manage-category.php');
            }
        }

        ?>

    </div>
</div>

