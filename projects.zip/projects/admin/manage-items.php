<?php
include('partials/menu.php');
?>

<div class="main-contain">
    <div class="wrapper">
        <h1> Manage Items</h1>

        <br /> <br />
        <?php
        if (isset($_SESSION['add'])) {
            echo $_SESSION['add'];
            unset($_SESSION['add']);
        }

        if (isset($_SESSION['delete'])) {
            echo $_SESSION['delete'];
            unset($_SESSION['delete']);
        }

        if (isset($_SESSION['upload'])) {
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
        }

        if (isset($_SESSION['unauthorize'])) {
            echo $_SESSION['unauthorize'];
            unset($_SESSION['unauthorize']);
        }

        if (isset($_SESSION['update'])) {
            echo $_SESSION['update'];
            unset($_SESSION['update']);
        }


        ?>

        <br /> <br />
        <!-- button to add amnin -->
        <a href="<?php echo SITEURL; ?>admin/add-item.php" class="btn-primary"> Add Item </a>
        <br /> <br /> <br />

        <table class="tbl-full">
            <tr>
                <th>S.N</th>
                <th>Day</th>
                <th>Itemname</th>
                <th>Category</th>
                <th>Price</th>
                <th>Featured</th>
                <th>Active</th>
                <th>Action</th>
            </tr>

            <?php
            //create a sql query to get all the food
            $sql = "SELECT * FROM items";

            //exexute the query
            $res = mysqli_query($conn, $sql);

            //count rows to check whether we have food or not
            $count = mysqli_num_rows($res);

            //create number variable and set default value as 1
            $sn = 1;

            if ($count > 0) {
                //we have food in database
                //get the foods from datbase and display
                while ($row = mysqli_fetch_assoc($res)) {
                    //get the value from individual column
                    $id = $row['id'];
                    $day = $row['day'];
                    $title = $row['title'];
                    $category = $row['category_id'];
                    $price = $row['price'];
                    $featured = $row['featured'];
                    $active = $row['active'];
            ?>
                    <tr>
                        <td><?php echo $sn++; ?></td>
                        <td><?php echo $day; ?></td>
                        <td><?php echo $title; ?></td>
                        <td><?php echo $category; ?></td>
                        <td><?php echo $price; ?></td>
                        <td><?php echo $featured; ?></td>
                        <td><?php echo $active; ?></td>
                        <td>
                            <a href="<?php echo SITEURL; ?>admin/update-item.php?id= <?php echo $id; ?>" class="btn-secondary"> Update Item </a>
                            <a href="<?php echo SITEURL; ?>admin/delete-item.php?id=<?php echo $id; ?>" class="btn-danger"> Delete Item </a>
                        </td>
                    </tr>


            <?php
                }
            } else {
                //food not added in database
                echo "<tr> <td colspan='7' class='error'> Food not added Yet</td> </tr>";
            }


            ?>

        </table>
    </div>

</div>

