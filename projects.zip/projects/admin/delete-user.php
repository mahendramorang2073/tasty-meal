<?php

//include constant.php file here
include('../config/constants.php');

//1. get the id of admin to be deleted
$id = $_GET['id'];

//2.create sql query to delete admin
$sql = "DELETE FROM users WHERE user_id=$id";

//Execute the query
$res = mysqli_query($conn, $sql);

//3.redirect to manage admin page with message(success/error)
//check whether the query ececuted is successfully or not
if ($res == TRUE) {
    //query ececuted successfully and admin deleted
    //echo "admin deleted";
    //create session variable to display message 
    $_SESSION['delete'] = "<div class='success'>User Deleted Successfully </div>";
    //redirect to manage admin page
    header('location:' . SITEURL . 'admin/manage-user.php');
} else {
    //Failed to delete admin
    //echo "Failed to delete admin";
    $_SESSION['delete'] = "<div class='success'> Failed To Delete User. Try Again Later </div>";
    //redirect to manage admin page
    header('location:' . SITEURL . 'admin/manage-user.php');
}
?>