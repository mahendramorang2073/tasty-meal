<?php
include('../config/constants.php');
?>

<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Admin login</title>
  <link rel="stylesheet" href="../css/form.css">
</head>

<body>
  <div class="center">
    <h1>Login</h1>
    <center>
    <?php
    if (isset($_SESSION['login'])) {
      echo $_SESSION['login'];
      unset($_SESSION['login']);
    }

    if (isset($_SESSION['no-login-message'])) {
      echo $_SESSION['no-login-message'];
      unset($_SESSION['no-login-message']);
    }
    if (isset($_SESSION['add'])) {
      echo $_SESSION['add'];
      unset($_SESSION['add']);
    }
    ?> </center>
    <form method="post" action="">
      <div class="txt_field">
        <input type="text" name="username" required>
        <span></span>
        <label>Username</label>
      </div>
      <div class="txt_field">
        <input type="password"  name="password" required>
        <span></span>
        <label>Password</label>
      </div>
      <!-- <div class="pass">Forgot Password?</div> -->
      <input type="submit"  name="submit" value="Login">
      <div class="signup_link">
        Not a member? <a href="./register.php">Signup</a>
      </div>
    </form>
  </div>

  <?Php
  //check whteher the submit button is clicked or not
  if (isset($_POST['submit'])) {
    //process for login
    //1. get the data from login form
    //$username = $_POST['username'];
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    //$password = md5($_POST['password']);
    $raw_password = md5($_POST['password']);
    $password = mysqli_real_escape_string($conn, $raw_password);

    //2. sql to check whether the user with username and password exits or not
    $sql = "SELECT * FROM admin WHERE username= '$username' AND password='$password'";

    //3. execute the query
    $res = mysqli_query($conn, $sql);

    //4. count rows to check whether the user exists or not
    $count = mysqli_num_rows($res);

    if ($count == 1) {
      //user available and login success
      $_SESSION['login'] = "<div class='success'> Login Successful </div>";
      $_SESSION['user'] = $username; //check whether the user is login or not and logout with unset
      //redirect to home page or dash board
      header('location:' . SITEURL . 'admin/index.php');
    } else {
      //user not available and login fail
      $_SESSION['login'] = "<div class='error'> Username Or Password Didnot Match </div>";
      //redirect to home page or dash board
      header('location:' . SITEURL . 'admin/login.php');
    }
  }


  ?>

</body>

</html>